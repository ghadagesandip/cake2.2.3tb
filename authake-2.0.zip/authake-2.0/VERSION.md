Authake plugin version 2.2.3
